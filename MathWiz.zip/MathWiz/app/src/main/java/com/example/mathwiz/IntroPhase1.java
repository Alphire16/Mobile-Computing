package com.example.mathwiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

public class IntroPhase1 extends AppCompatActivity {

    TextView txt;
    Handler h = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro_phase1);

        txt = findViewById(R.id.txtv);
        txt.setText("You will have to answer 10 Arithmetic equations.\n Answer seven correctly to fight the Boss.");
        h.postDelayed(runPhase1,5000);
    }

    private Runnable runPhase1 = new Runnable() {
        @Override
        public void run() {
            Intent i = new Intent(IntroPhase1.this,Phase1.class);
            startActivity(i);
            finish();
        }
    };
}
