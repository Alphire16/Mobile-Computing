package com.example.mathwiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class BossIntro extends AppCompatActivity {


    TextView t;
    Button BF,QtG;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_boss_intro);

        t = findViewById(R.id.txtset);
        t.setText("Congratulations, You have won your way to fight the BOSS.\n Do yoy wish to fight?");
        BF = findViewById(R.id.FightBoss);
        QtG = findViewById(R.id.Quitgame);

        BF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(BossIntro.this, BossRules.class));
                finish();
            }
        });

        QtG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(BossIntro.this, "You quit the game.", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }
}
