package com.example.mathwiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import static android.graphics.Typeface.createFromAsset;

public class MainActivity extends AppCompatActivity {

    Button strt,qt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        strt = findViewById(R.id.Start);
        qt = findViewById(R.id.Quit);

        strt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,IntroPhase1.class);
                startActivity(i);
                finish();
            }
        });

        qt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "You quit the game.", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }
}
