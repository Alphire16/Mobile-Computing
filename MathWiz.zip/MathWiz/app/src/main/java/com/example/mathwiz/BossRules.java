package com.example.mathwiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

public class BossRules extends AppCompatActivity {

    TextView br;
    Handler H = new Handler();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_boss_rules);

        br = findViewById(R.id.brtxt);
        br.setText("You are going to fight the Boss.\nDefeat him in a game of Rock Paper Scissor.\n Get 5 points before the Boss to win.");
        H.postDelayed(runPhase2,5000);
    }

    private Runnable runPhase2 = new Runnable() {
        @Override
        public void run() {
            Intent i = new Intent(BossRules.this,BossFight.class);
            startActivity(i);
            finish();
        }
    };
}
