package com.example.mathwiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class Phase1 extends AppCompatActivity {

    TextView Op1,Op2,opr;
    Button Sub;
    EditText ans;
    String op1,op2,operator,Ops [] = {"+","-"},res;
    Random r = new Random();
    int n1,n2,x,counter = 0,finalcount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phase1);

        Op1 = findViewById(R.id.Operand1);
        Op2 = findViewById(R.id.Operand2);
        opr = findViewById(R.id.Operator);
        Sub = findViewById(R.id.Submit);
        ans = findViewById(R.id.Answer);

        QuestionSet();
    }

    public void QuestionSet(){

        n1 = r.nextInt(98)+1;
        n2 = r.nextInt(98)+1;

        if (n2 > n1){
            n1 = n1 + n2;
            n2 = n1 - n2;
            n1 = n1 - n2;
        }

        op1 = String.valueOf(n1);
        op2 = String.valueOf(n2);
        operator = Ops[r.nextInt(Ops.length)];
        SettingText();
    }


    public void SettingText(){

        Op1.setText(op1);
        Op2.setText(op2);
        opr.setText(operator);

    }

    public void Result(View view) {

        res = ans.getText().toString();

        switch (operator) {
            case "+":
                x = n1+n2;
                break;
            case "-":
                x = n1-n2;
                break;
        }

        if (res.equals(String.valueOf(x))){
            counter++;}
        finalcount++;
        if (finalcount == 10){
            CorrectAns();
        }
        QuestionSet();
        ans.setText("");
    }

    public void CorrectAns() {

        Intent i ;
        if (counter>=7){
            i = new Intent(Phase1.this,BossIntro.class);
            startActivity(i);
            finish();
        }
        else{
            i = new Intent(Phase1.this,Loss.class);
            startActivity(i);
            finish();
        }
    }
}
