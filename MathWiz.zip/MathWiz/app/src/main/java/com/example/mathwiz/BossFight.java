package com.example.mathwiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.Random;

public class BossFight extends AppCompatActivity {

    TextView user,boss,wlt;
    Random r = new Random();
    int userscore = 0,bossscore= 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_boss_fight);

        user = findViewById(R.id.UserScore);
        boss = findViewById(R.id.BossScore);
        wlt = findViewById(R.id.WinLoseTie);

        user.setText("0");
        boss.setText("0");
        wlt.setText("-");
    }

    public void PlayGame(View view) {

        int userSelect = Integer.parseInt(view.getTag().toString());
        PlayMatch(userSelect);
    }
    public void PlayMatch(int userselect){

        int max = 3, min = 1;
        int bossselect =r.nextInt(max)+min;

        if(userselect == bossselect){
            wlt.setText(R.string.tie);
        }
        else if ((userselect-bossselect)%3 == 1){
            wlt.setText(R.string.win);
            userscore++;
            user.setText(String.valueOf(userscore));
        }
        else{
            wlt.setText(R.string.lose);
            bossscore++;
            boss.setText(String.valueOf(bossscore));
        }
        if (userscore == 5 || bossscore == 5){
            WinorLose(userscore,bossscore);
        }

    }

    public void WinorLose(int win,int lose){

        if ( win == 5){
            startActivity(new Intent(BossFight.this, GameWon.class));
            finish();
        }
        else if (lose == 5){
            startActivity(new Intent(BossFight.this, Loss.class));
            finish();
        }

    }
}
