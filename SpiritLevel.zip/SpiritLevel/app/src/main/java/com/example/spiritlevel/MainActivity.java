package com.example.spiritlevel;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView Txt;
    float[] mValuesMagnet      = new float[3];
    float[] mValuesAccel       = new float[3];
    float[] mValuesOrientation = new float[3];
    float[] mRotationMatrix    = new float[9];
    Handler handler = new Handler();
    boolean close = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Txt = findViewById(R.id.Display);

        SensorManager sensorManager = (SensorManager) this.getSystemService(SENSOR_SERVICE);
        SensorEventListener mEventListener = new SensorEventListener() {
            public void onAccuracyChanged(Sensor sensor, int accuracy) {
            }

            public void onSensorChanged(SensorEvent event) {
                // Handle the events for which we registered
                switch (event.sensor.getType()) {
                    case Sensor.TYPE_ACCELEROMETER:
                        System.arraycopy(event.values, 0, mValuesAccel, 0, 3);
                        break;

                    case Sensor.TYPE_MAGNETIC_FIELD:
                        System.arraycopy(event.values, 0, mValuesMagnet, 0, 3);
                        break;
                }
            }
        };
        setListeners(sensorManager, mEventListener);
        handler.postDelayed(r, 10);
    }


    Runnable r = new Runnable() {
        @Override
        public void run() {
            SensorManager.getRotationMatrix(mRotationMatrix, null, mValuesAccel, mValuesMagnet);
            SensorManager.getOrientation(mRotationMatrix, mValuesOrientation);
            final CharSequence test;
            test = "X:" + mValuesOrientation[0] +"\nY: "+mValuesOrientation[1]+ "\nZ: "+ mValuesOrientation[2];
            Txt.setText(test);
            if (close){
                onBackPressed();
            }
            handler.postDelayed(r, 10);
        }
    };



    public void setListeners(SensorManager sensorManager, SensorEventListener mEventListener)
    {
        sensorManager.registerListener(mEventListener, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
                SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(mEventListener, sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD),
                SensorManager.SENSOR_DELAY_NORMAL);
    }

    public void closeApp(View view) {
        close = true;
    }
}
