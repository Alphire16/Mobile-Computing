package com.example.reflexchecker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class ReflexCheck extends AppCompatActivity {

    TextView RanInc;
    CheckBox chkbacon, chkbeer, chkmilk, chkcocktail, chktaco, chksushi;
    int f = 0;
    int r = new Random().nextInt(3) + 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reflex_check);

        RanInc = findViewById(R.id.RandInc);
        chkbacon = findViewById(R.id.ChkBacon);
        chkbeer = findViewById(R.id.ChkBeer);
        chkcocktail = findViewById(R.id.ChkCocktail);
        chkmilk = findViewById(R.id.ChkMilk);
        chktaco = findViewById(R.id.ChkTaco);
        chksushi = findViewById(R.id.ChkSushi);

        RandomText(r);
    }


    public void submit(View view) {
        int f = Checker(r);
        if (f == 1) {
            Toast.makeText(ReflexCheck.this, "You have Great Reflexes", Toast.LENGTH_LONG).show();
            Intent i = new Intent(ReflexCheck.this, MainActivity.class);
            startActivity(i);

        } else {
            Toast.makeText(ReflexCheck.this, "Please Fulfill the Conditions...", Toast.LENGTH_SHORT).show();
        }
    }

    public int Checker(int r) {

        switch (r) {

            case 1:
                if (chksushi.isChecked() && chktaco.isChecked() && chkcocktail.isChecked() && chkbeer.isChecked() && chkbacon.isChecked() && chkmilk.isChecked()) {
                    f = 1;
                } else
                    f = 0;

            case 2:
                if (chkcocktail.isChecked() && chkbeer.isChecked() && chkmilk.isChecked()) {
                    f = 1;
                } else {
                    f = 0;
                }
                break;

            case 3:
                if (!(chksushi.isChecked() && chktaco.isChecked() && chkcocktail.isChecked() && chkbeer.isChecked() && chkbacon.isChecked() && chkmilk.isChecked())) {
                    f = 1;
                } else
                    f = 0;
                break;

            default:
                break;
        }
        return f;
    }

    public void RandomText(int r) {

        switch (r) {

            case 1:
                RanInc.setText(R.string.sai);
                break;

            case 2:
                RanInc.setText(R.string.sod);
                break;

            case 3:
                RanInc.setText(R.string.dai);
                chkmilk.setChecked(true);
                chkbacon.setChecked(true);
                chkbeer.setChecked(true);
                chkcocktail.setChecked(true);
                chksushi.setChecked(true);
                chktaco.setChecked(true);
                break;

        }
    }
}


