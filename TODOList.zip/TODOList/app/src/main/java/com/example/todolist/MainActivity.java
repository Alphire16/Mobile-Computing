package com.example.todolist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<String> itemlist;
    ArrayAdapter<String> itemAdapter;
    ListView listView;
    Button AddItem;
    EditText NewItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.TODOList);
        AddItem = findViewById(R.id.ADDITEM);
        NewItem = findViewById(R.id.NewItem);

        AddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AddItemsToListView(v);

            }
        });

        itemlist = new ArrayList<>();
        itemAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,itemlist);
        listView.setAdapter(itemAdapter);
        setupItemListListner();

    }

    private void setupItemListListner() {

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Context con = getApplicationContext();
                Toast.makeText(con, "Item Removed", Toast.LENGTH_SHORT).show();
                itemlist.remove(position);
                itemAdapter.notifyDataSetChanged();
                return true;
            }
        });

    }


    private void AddItemsToListView(View v) {
        String Txt = NewItem.getText().toString();

        if (!(Txt.equals(""))){
            itemAdapter.add(Txt);
        }
        else
            Toast.makeText(this, "Please Enter Text...", Toast.LENGTH_SHORT).show();
    }
}
