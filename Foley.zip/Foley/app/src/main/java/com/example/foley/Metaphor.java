package com.example.foley;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;

public class Metaphor extends AppCompatActivity {


    SoundPool soundPool;
    int cat,cow,dog,duck,rooster,zebra;
    String butname, names[];
    InputStream inputStream;
    Bitmap bitmap;
    Button imgdis;
    ImageView img;
    String TAG = "MyAPP";

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_metaphor);

        Intent intent = getIntent();
        butname = intent.getStringExtra(MainActivity.EXTRA_TEXT);
        imgdis = findViewById(R.id.ImgDis);
        try {
            names = getAssets().list("pics");
        } catch (IOException e) {
            e.printStackTrace();
        }

        AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        soundPool = new SoundPool.Builder()
                .setMaxStreams(6)
                .setAudioAttributes(audioAttributes)
                .build();

        cat = soundPool.load(this, R.raw.cat, 1);
        cow = soundPool.load(this, R.raw.cow, 1);
        dog = soundPool.load(this, R.raw.dog, 1);
        duck = soundPool.load(this, R.raw.duck, 1);
        rooster = soundPool.load(this, R.raw.rooster, 1);
        zebra = soundPool.load(this, R.raw.zebra, 1);

        imgdis.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_DOWN) {
                    try {
                        Log.d(TAG, "onTouch: ");
                        onPlay(v);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                return false;
            }
        });

    }


    public void onPlay(View v) throws IOException {

        switch (butname) {
            case "cat":
                soundPool.play(cat,1,1,1,0,1);
                break;
            case "cow":
                soundPool.play(cow,1,1,1,0,1);
                break;
            case "dog":
                soundPool.play(dog,1,1,1,0,1);
                break;
            case "duck":
                soundPool.play(duck,1,1,1,0,1);
                break;
            case "rooster":
                soundPool.play(rooster,1,1,1,0,1);
                break;
            case "zebra":
                soundPool.play(zebra,1,1,1,0,1);
                break;
        }

    }
}
