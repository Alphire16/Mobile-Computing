package com.example.foley;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_TEXT = "com.example.foley.EXTRA_TEXT";
    String name;
    Intent i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        i = new Intent(MainActivity.this,Metaphor.class);
    }

    public void onClick(View v){

        switch (v.getId()) {
            case R.id.cat:
                name = "cat";
                i.putExtra(EXTRA_TEXT,name);
                startActivity(i);
                break;
            case R.id.cow:
                name = "cow";
                i.putExtra(EXTRA_TEXT,name);
                startActivity(i);
                break;
            case R.id.dog:
                name = "dog";
                i.putExtra(EXTRA_TEXT,name);
                startActivity(i);
                break;
            case R.id.duck:
                name = "duck";
                i.putExtra(EXTRA_TEXT,name);
                startActivity(i);
                break;
            case R.id.rooster:
                name = "rooster";
                i.putExtra(EXTRA_TEXT,name);
                startActivity(i);
                break;
            case R.id.zebra:
                name = "zebra";
                i.putExtra(EXTRA_TEXT,name);
                startActivity(i);
                break;
        }


    }
}
