package com.example.guessthatpokemon;

public interface BasicInterface {
    public void LevelMode(String Level, int LevelNo);
    public void UpdateScore();
    public void QuestionCounter();
    public void Hide();

    void reset();
}
