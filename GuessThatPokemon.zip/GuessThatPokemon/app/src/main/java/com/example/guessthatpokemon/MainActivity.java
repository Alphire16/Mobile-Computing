package com.example.guessthatpokemon;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;



public class MainActivity extends AppCompatActivity implements BasicInterface {


    private static final String TAG = "my app";
    GameFragment GM = new GameFragment();
    StatusFragment ST = new StatusFragment();
    QuestionFragment QT = new QuestionFragment();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG,"main34");
        FragmentManager FM = getSupportFragmentManager();
        FragmentTransaction FT = FM.beginTransaction();

        //Log.d(TAG,"main12");
        FT.add(R.id.GameFrag,GM);
        FT.add(R.id.StatusFrag,ST);
        FT.add(R.id.QuestionFrag,QT);
        FT.show(GM);
        FT.hide(ST);
        FT.hide(QT);
        FT.commit();
        //Log.d(TAG,"main");

    }

    @Override
    public void LevelMode(String Level, int LevelNo) {
        ST.setLevel(Level,LevelNo);
    }

    @Override
    public void UpdateScore() {
        ST.UpdateScore();
    }

    @Override
    public void QuestionCounter() {
        ST.updateQuestionCounter();
    }

    @Override
    public void Hide() {
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
////        ft.add(R.id.GameFrag,GM);
//        if(!ST.isAdded()) ft.add(R.id.StatusFrag,ST);
//        if(!QT.isAdded()) ft.add(R.id.QuestionFrag,QT);
//        if(GM.isAdded()) ft.remove(GM);
        ft.hide(GM);
        ft.show(ST);
        ft.show(QT);
        ft.commit();
        ST.updateStatusText();
        Log.d("My app","Been here"+ST.isAdded());
    }

    @Override
    public void reset() {

    }

}
