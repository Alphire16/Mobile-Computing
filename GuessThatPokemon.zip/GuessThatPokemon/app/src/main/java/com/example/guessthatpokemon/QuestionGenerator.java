package com.example.guessthatpokemon;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Random;

class QuestionGenerator {

    public int Questions[] = {0,1,2,3,4,5};

    public String Choices [][] =  {{"Groudon","Kyogre","Arceus","Rayquaza"},
                                    {"Vulpix","Bayleef","Rapidash","Onix"},
                                    {"Cyndaquil","Charmander","Eevee","Dratini"},
                                    {"Ratata","Pidgey","Geodude","Jolteon"},
                                    {"Zigzagoon","Moltres","Lapras","Horsea"},
                                    {"Meowth","Pikachu","Goldeen","Zubat"}};

    private String CorrectAnswers[] = {Choices[0][2],Choices[1][1],Choices[2][0],Choices[3][3],Choices[4][2],Choices[5][1]};

    public int getQuestion(int a){
        return Questions[a];
    }

    public String getChoice(int a, int b){
        String choice = Choices[a][b];
        return choice;
    }
    public String getCorrectAnswer(int a){
        String correctans = CorrectAnswers[a];
        return correctans;
    }



}
