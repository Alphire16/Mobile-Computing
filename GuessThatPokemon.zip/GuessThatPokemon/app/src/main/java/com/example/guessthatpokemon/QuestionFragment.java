package com.example.guessthatpokemon;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Objects;


/**
 * A simple {@link Fragment} subclass.
 */
public class QuestionFragment extends Fragment {

    private BasicInterface listener;
    private String names[];
    private ImageView img;
    private int i = 0;
    private Button opt1,opt2,opt3,opt4;
    public int Score = 0;
    QuestionGenerator QG = new QuestionGenerator();


    public QuestionFragment() {
        // Required empty public constructor
        Log.d("my app", "Construcor");
    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_question, container, false);

        try {
            names = Objects.requireNonNull(getActivity()).getAssets().list("pokemon");
        }
        catch (IOException e) {
            e.printStackTrace();
        }

        img = view.findViewById(R.id.img);
        opt1 = view.findViewById(R.id.Option1);
        opt2 = view.findViewById(R.id.Option2);
        opt3 = view.findViewById(R.id.Option3);
        opt4 = view.findViewById(R.id.Option4);

        UpdateIMG();

       opt1.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               QuestionFragment.this.onClick(v);
           }
       });

        opt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                QuestionFragment.this.onClick(v);
            }
        });

        opt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                QuestionFragment.this.onClick(v);
            }
        });

        opt4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                QuestionFragment.this.onClick(v);
            }
        });

        return view;
    }

    public void onClick(View v){
        if (((Button) v).getText().toString().equals(QG.getCorrectAnswer(i))){
            listener.UpdateScore();
            Toast.makeText(getContext(), "Right", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(getContext(), "Wrong", Toast.LENGTH_SHORT).show();
        }
        listener.QuestionCounter();
        if(++i < QG.Questions.length)
            UpdateIMG();
    }

    private void UpdateIMG(){
        Log.d("my app","I:"+i);
        InputStream stream ;
        try {
            stream = Objects.requireNonNull(getActivity()).getAssets().open("pokemon/"+names[QG.getQuestion(i)]);
            Bitmap bit = BitmapFactory.decodeStream(stream);
            img.setImageBitmap(bit);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        opt1.setText(QG.getChoice(i,0));
        opt2.setText(QG.getChoice(i,1));
        opt3.setText(QG.getChoice(i,2));
        opt4.setText(QG.getChoice(i,3));
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        listener = (BasicInterface) context;
    }

}
