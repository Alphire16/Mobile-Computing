package com.example.guessthatpokemon;


import android.R.layout;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


/**
 * A simple {@link Fragment} subclass.
 */
public class GameFragment extends Fragment {

    private BasicInterface listener;
    private Button StartGame;
    private Spinner lvl;
    private static final String[] levels = {"Easy","Medium","Hard"};
    private static final int[] levelsLimit = {2,4,6};
//    private StatusFragment StatFG = new StatusFragment();

    public GameFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_game, container, false);
        StartGame = view.findViewById(R.id.xyz);
        lvl = (Spinner) view.findViewById(R.id.LvlDifficulty);

        final ArrayAdapter<String> spinadapt = new ArrayAdapter<>( getContext(),android.R.layout.simple_spinner_item, levels);
        spinadapt.setDropDownViewResource(layout.simple_spinner_dropdown_item);
        lvl.setAdapter(spinadapt);

        lvl.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                listener.LevelMode(levels[position],levelsLimit[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        StartGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.Hide();
            }
        });

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        listener = (BasicInterface) context;
    }

}
