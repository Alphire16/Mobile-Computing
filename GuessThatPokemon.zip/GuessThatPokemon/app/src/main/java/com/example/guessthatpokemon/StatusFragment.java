package com.example.guessthatpokemon;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Chronometer;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class StatusFragment extends Fragment {

    public static final String TIMER = "com.example.guessthatpokemon.TIMER";
    public static final String SCORE = "com.example.guessthatpokemon.SCORE";
    public static final String QUESTION = "com.example.guessthatpokemon.QUESTION";
    int Scores = 0, QuestionNumber = 0,questioncounter = 1;
    Chronometer timer;
    TextView ScrTxt;
    String level;
    String x;
    private BasicInterface listener;

    public StatusFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_status, container, false);


        timer = view.findViewById(R.id.Timer);
        ScrTxt = view.findViewById(R.id.ScoreTxt);
        StartTimer();
        return view;
    }

    public void updateStatusText(){
        String temp = level+":"+Scores+"/"+QuestionNumber;
        ScrTxt.setText(temp);
    }

    public void setLevel(String Level, int LevelNo){
        level = Level;
        QuestionNumber = LevelNo;
    }

    private void StartTimer(){
        timer.start();
    }

    public void UpdateScore(){
        Scores++;
        updateStatusText();
    }

    public void updateQuestionCounter(){
        questioncounter++;
        if (questioncounter > QuestionNumber){
            StopTimer();
        }
    }

    public void StopTimer(){
        timer.stop();
        x = String.valueOf(timer.getText());
        Intent i = new Intent(getActivity(),End.class);
        i.putExtra(TIMER,x);
        i.putExtra(SCORE,Scores);
        i.putExtra(QUESTION,QuestionNumber);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        listener = (BasicInterface) context;
    }

}
