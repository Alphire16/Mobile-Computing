package com.example.guessthatpokemon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class End extends AppCompatActivity {

    TextView ETxt;
    Button close;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end);


        Intent i = getIntent();
        String time = i.getStringExtra(StatusFragment.TIMER);
        int scr = i.getIntExtra(StatusFragment.SCORE,0);
        int qun = i.getIntExtra(StatusFragment.QUESTION,0);


        ETxt = findViewById(R.id.EndScrn);
        close = findViewById(R.id.Close);

        if (scr == qun){
            ETxt.setText("You have completed\nthe quiz in "+time+"\nsecs");
        }
        else
            ETxt.setText("You have not completed the quiz ");

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }
}
