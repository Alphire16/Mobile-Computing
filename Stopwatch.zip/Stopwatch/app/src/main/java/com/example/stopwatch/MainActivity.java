package com.example.stopwatch;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Chronometer;

public class MainActivity extends AppCompatActivity {

    Chronometer chrono;
    long pauseoffset = 0;
    boolean running = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chrono = findViewById(R.id.chronometer);
    }

    public void startStopWatch(View v)
    {
        if(!running){
            chrono.setBase(SystemClock.elapsedRealtime() - pauseoffset);
            chrono.start();
            running = true;
        }
    }

    public void pauseStopWatch(View v)
    {
        if(running){
            chrono.stop();
            pauseoffset = SystemClock.elapsedRealtime() - chrono.getBase();
            running = false;
        }
    }

    public void resetStopWatch(View v)
    {
        chrono.setBase(SystemClock.elapsedRealtime());
        pauseoffset = 0;
    }
}
